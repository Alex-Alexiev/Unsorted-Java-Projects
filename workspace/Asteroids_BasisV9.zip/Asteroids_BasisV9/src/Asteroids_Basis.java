import processing.core.PApplet;
import java.lang.System;
import processing.core.PVector;

import java.awt.Color;
import java.util.ArrayList;

public class Asteroids_Basis extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Asteroids_Basis");
	}

	public void settings() {
		size(1000, 700);
	}

	ArrayList<Asteroids> asteroids;
	ArrayList<Projectiles> shots;
	ArrayList<Integer> ast_for_deletion;
	ArrayList<Integer> shots_for_deletion;
	Score score;
	movingTriangle spaceship;
	movingText loseText;
	Projectiles shot;
	int b = 1;
	boolean clicked = false;

	int num_of_asteroids = 7;

	public void setup() {
		surface.setResizable(true);
		frameRate(60);
		fill(255);
		ast_for_deletion = new ArrayList<Integer>();
		asteroids = new ArrayList<Asteroids>();
		shots = new ArrayList<Projectiles>();
		shots_for_deletion = new ArrayList<Integer>();
		for (int i = 0; i < num_of_asteroids; i++) {

			int negator = ((int) random(0, 1) == 0 ? -1 : 1);
			asteroids.add(new Asteroids(this, (int) random(30, width - 30), (int) random(30, height - 30), 100, 100,
					(int) random(1, 2) * negator, (int) random(1, 2) * negator, new Color(0, 0, 0),
					new Color(255, 255, 255), 5));
		}
		score = new Score(this, 0, width / 4, 50, 28, 0, 0, new Color(255, 255, 255), 3);

		loseText = new movingText(this, "YOU SUCK", width / 2, height / 2, 50, 0, 0, new Color(255, 255, 255), 3);

		PVector[] vertices = new PVector[] { new PVector(width / 2, height / 2),
				new PVector(width / 2 + 10, height / 2 + 30), new PVector(width / 2 - 10, height / 2 + 30) };
		spaceship = new movingTriangle(this, vertices, new PVector(0, 1), (float) 0.0, (float) 0.0, new Color(0, 0, 0),
				new Color(255, 255, 255), 2);

		int negator = ((int) random(0, 1) == 0 ? -1 : 1);

		shot = new Projectiles(this, 10, 10, 10, 10, (int) random(1, 2) * negator, (int) random(1, 2) * negator,
				new Color(0, 0, 0), new Color(255, 255, 255), 5);
	}

	public void draw() {

		move();
		
		println( spaceship.getCom());

	}

	public void keyTyped() {

		clicked = true;

	}

	public void move() {

		background(0);

		if (ast_for_deletion.size() > 0) {

			ast_for_deletion = new ArrayList<Integer>();
		}

		if (shots_for_deletion.size() > 0) {

			shots_for_deletion = new ArrayList<Integer>();
		}

		if (keyPressed) {
			if (keyCode == LEFT) {
				spaceship.setAngleVelocity((float) -0.1);
			}
			if (keyCode == RIGHT) {
				spaceship.setAngleVelocity((float) 0.1);
			}
			if (keyCode == UP) {
				spaceship.setVelMag(-7);
			}
			if (keyCode == DOWN) {
				spaceship.setVelMag(7);
			}
			if (key == ' ') {

				if (clicked == true) {

					shots.add(new Projectiles(this, (int) spaceship.getCom().x, (int) spaceship.getCom().y, 10, 10,
							(int) (-spaceship.getVelocity().x * 10), (int) (-spaceship.getVelocity().y * 10),
							new Color(255, 255, 255), new Color(255, 255, 255), 5));

					clicked = false;

				}

			}
		} else {
			spaceship.setAngleVelocity(0);
			spaceship.setVelMag(0);
		}
		for (Asteroids i : asteroids) {

			for (Projectiles q : shots) {

				if (q.overlaps(i)) {

					ast_for_deletion.add(asteroids.indexOf(i));
					shots_for_deletion.add(shots.indexOf(q));

				}

			}

		}

		for (int i = ast_for_deletion.size() - 1; i >= 0; i--) {

			asteroids.remove((int) ast_for_deletion.get(i));

		}

		for (int i = shots_for_deletion.size() - 1; i >= 0; i--) {
			shots.remove((int) shots_for_deletion.get(i));

		}

		for (int i = 0; i < asteroids.size(); i++) {
			asteroids.get(i).move();
			asteroids.get(i).display();
		}

		for (int i = 0; i < shots.size(); i++) {

			shots.get(i).move();
			shots.get(i).display();

		}

		spaceship.move();
		spaceship.display();

	}

}
